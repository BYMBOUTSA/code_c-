#include <iostream>
#include <cstdlib>
#include <cstring>


int main () {

    std::string s;
    s = "Bienvenue";
    std::cout << s.find("e") << std::endl;
    std::cout << s.rfind('e') << std::endl;
    /* la méthode find nous donne la première position d'un caractère 
    au sein de la chaine de caractères de type std::string et rfind()
    nous donne la position du dernier caractère passé en paramètre
    */

    return EXIT_SUCCESS;
}