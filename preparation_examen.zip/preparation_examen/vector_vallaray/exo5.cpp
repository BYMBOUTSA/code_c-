#include <iostream>
#include <cstdlib>
#include <cstring>


int main () {

    std::string s3, s4;
    s3 = "Bonjour";

    // affectation de s3 à s4
    s4 = s3;
    // affichage de s3 et s45
    std::cout << s3 << std::endl;
    std::cout << s4 << std::endl;

    // Modification du 1er caractère de s4
    s4[0] = 'b';

    // réaffichage de s3 et s4
    std::cout << s3 << std::endl;
    std::cout << s4 << std::endl;

    /* On peut en conslure que l'opération d'affectation est
    une copie qu'on effectue et donc en modifiant à nouveau, une valaur on ne 
    modifie plus l'autre.
    */

    return EXIT_SUCCESS;
}