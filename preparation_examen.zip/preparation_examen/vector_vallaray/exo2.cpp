#include <iostream>
#include <cstdlib>
#include <string>

int main () {

    std::string s1, s2, s3;
    s1 = "Bonjour";
    s2 = " à tous";
    s3 = s1 + s2;
    std::cout << s3 << std::endl;
    
    return EXIT_SUCCESS;
}