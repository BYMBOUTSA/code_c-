#include <iostream>
#include <cstdlib>
#include <valarray>

/*
 * Rôle : afficher le contenu du vecteur sur la sortie standard 
*/
void afficherVecteur(std::valarray<double> v) {
    for (auto x : v)
        std::cout << x << " ";
    std::cout << std::endl;
}

int main () {

    std::valarray<double> v1 = {1.2, 2.4, 3.2};

    // affichage de la taille et du contenu de v1
    std::cout << v1.size() << std::endl;
    afficherVecteur(v1);

    std::cout << "------------------" << std::endl;

    // Agrandissement du std::valarray
    v1.resize(10);

    // affichage de la nouvelle taille et du contenu du tableau
    std::cout << v1.size() << std::endl;
    afficherVecteur(v1);
    // Que toutes les valeurs sont initialisées à 0

    return EXIT_SUCCESS;
}

