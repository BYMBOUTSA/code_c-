#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>


// Procédure afficherVecteur
/*
*   Rôle : afficher les éléments du vecteur passé en paramètre
*  En utilisant la notation []
*/
/*void afficherVecteur(std::vector<std::string> v) {
    for (int i = 0; i < v.size(); i++)
        std::cout << v[i] << " ";
}*/


/*
*   Rôle : afficher les éléments du vecteur passé en paramètre
*  En utilisant l'énoncé forEach
*/
void afficherVecteur(std::vector<std::string> v) {
    for(auto x : v)
        std::cout << x << " ";
}


int main () {

    std::vector<int> v1;
    std::vector<std::string> v2;
    std::vector<std::vector<double>> v3;
    std::vector<int> v4 (10);
    std::vector<std::string> v5 = {"ab", "ef", "azy"};

    // affichage de la taille de chacun de ces vecteurs
    std::cout << v1.size() << std::endl;
    std::cout << v2.size() << std::endl;
    std::cout << v3.size() << std::endl;
    std::cout << v4.size() << std::endl;
    std::cout << v5.size() << std::endl;

    // écriture de v5 sur la sortie standard
    //std::cout << v5 << std::endl; // Il y a une erreur, car c'est un tableau on ne peut pas l'afficher ainsi sur la sortie standard

    afficherVecteur(v5);

    return EXIT_SUCCESS;
}