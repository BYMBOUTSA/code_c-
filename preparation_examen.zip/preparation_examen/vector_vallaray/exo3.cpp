#include <iostream>
#include <cstdlib>
#include <cstring>



int main () {

    std::string s1, s2, s3;
    s1 = "Bonjour";
    s2 = " à tous";
    strcat(s3, s1);
    strcat(s3, s2);
    std::cout << s3 << std::endl; // nous avons un problème car la fonction strcat prend comme premier
    // paramètre une char, et comme second paramètre une const char *

    // Code fonctionnel de la concaténation avec strcat
    /*const char * s1 = "Bonjour";
    const char * s2 = " à tous";
    char s3[] = "";
    strcat(s3, s1);
    strcat(s3, s2);*/


    return EXIT_SUCCESS;
}