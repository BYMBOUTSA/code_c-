#include <iostream>
#include <cstdlib>
#include <valarray>

/*
 * Rôle : renvoie le produit scalaire des vecteurs v1 et v2
*/
double produitScalaire(const std::valarray<double> &v1, const std::valarray<double> &v2) {
    double produit = 0;
    if (v1.size() != v2.size())
        return EXIT_FAILURE;
    for(int i = 0; i < v1.size(); i++)
        produit = v1[i] * v2[i];
    return produit;
}


int main () {

    std::valarray<double> v1 = {1.2, 1.3, 5.8, 6.3};
    std::valarray<double> v2 = {2.3, 3.6, 4.1, 4.6};

    std::cout << produitScalaire(v1, v2) << std::endl;

    return EXIT_SUCCESS;
}