#include <iostream>
#include <cstdlib>
#include <vector>

/*
 * Rôle :  afficher le vecteur sur la sortie standard
*/
void afficherVecteur(std::vector<int> v) {
    for(auto x : v)
        std::cout << x << " ";
    std::cout << std::endl;
}


/*
 * Rôle : initialiser un vecteur avec les n premières valeurs paires positives
*/
// 1er méthode en utilisant une variable intermédiaire
// Ici il faut passer le vecteur par référence car il va être modifier au sein de la procédure
// si on ne le passe pas référence on aura rien qui va s'afficher
/*void vecteurPair(std::vector<int> &v, int n) {
    int pairVecteur = 0;
    for (int i = 0; i < n; i++) {
        v.push_back(pairVecteur);
        pairVecteur += 2;
    }
}*/

// 2ème méthode un peu plus direct
void vecteurPair(std::vector<int> &v, int n) {
    for (int i = 0; i < n; i++) 
        v.push_back(i * 2);
}


int main () {

    std::vector<int> v1;
    int n = 6;

    vecteurPair(v1, 6);
    afficherVecteur(v1);

    return EXIT_SUCCESS;
}