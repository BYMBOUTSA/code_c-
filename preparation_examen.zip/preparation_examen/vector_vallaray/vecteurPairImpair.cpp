#include <iostream>
#include <cstdlib>
#include <vector>


/*
 * Rôle : Afficher le veteur sur la sortie standard
*/
void afficherVecteur(std::vector<int> v) {
    for(auto x : v)
        std::cout << x << " ";
    std::cout << std::endl;
}

/*
 * Rôle : initialiser un vecteur v avec les n premières valauers paires positives 
*/
void vecteurPair(std::vector<int> & v, int n) {
    for (int i = 0; i < n; i++) 
        v.push_back(i * 2);
} 

/*
 * Rôle : insérer un vecteur v qui contient une suite de nombres pairs
*/
// Comme on modifie la valeur du vecteur v au sein de la procédure
// il faut passer v par référence
void vecteurPairImpair(std::vector<int> &v) {
    for (int i = 1; i <= v.size(); i += 2)
        v.insert(v.begin() + i, i);
}


int main () {
    
    std::vector<int> v1;
    int n = 6;

    vecteurPair(v1, 6);
    std::cout << v1.size() << std::endl;
    vecteurPairImpair(v1);
    afficherVecteur(v1);

    return EXIT_SUCCESS;
}