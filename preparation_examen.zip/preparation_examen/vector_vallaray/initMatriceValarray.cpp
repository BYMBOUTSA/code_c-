#include <iostream>
#include <cstdlib>
#include <valarray>
#include <ctime>


/*
 * Rôle : renvoie une matrice m x n initialisée aléatoirement 
*/
std::valarray<std::valarray<int>> initMatrice(int m, int n) {
    std::srand(std::time(nullptr));
    std::valarray<std::valarray<int>> mat;
    // modification de la taille du tableau
    mat.resize(m);
    std::valarray<int> temp;
    for (int i = 0; i < m; i++) {
        temp.resize(n);
        for (int j = 0; j < n; j++)
            temp[j] = std::rand() % 10;
        mat[i] = temp;
    }
    return mat;
}

/*
 * Rôle : écrire la matrice passée en paramètresur la sortie standard
*/
void afficherMatrice(std::valarray<std::valarray<int>> mat) {
    for (auto x : mat) {
        for (auto y : x)
            std::cout << y << " ";
        std::cout << std::endl;
    }
}



int main () {

    int n = 3, m = 3;

    std::valarray<std::valarray<int>> mat = initMatrice(m, n);

    afficherMatrice(mat);

    return EXIT_SUCCESS;
}