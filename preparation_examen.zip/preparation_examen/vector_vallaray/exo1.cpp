#include <iostream>
#include <cstdlib>
#include <string>


int main () {

    std::string s;
    std::cout << "Donnez une chaîne de caractères : ";
    std::cin >> s;
    std::cout << s << " : " << "longueur = " << s.length() << std::endl;

    return EXIT_SUCCESS;
}