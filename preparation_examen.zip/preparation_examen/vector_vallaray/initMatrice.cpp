#include <iostream>
#include <cstdlib>
#include <vector>
#include <ctime>


/*
 * Rôle : renvoie une matrice m x n intialisée aléatoirement
*/
std::vector<std::vector<int>> initMatrice(int m, int n) {
    std::srand(std::time(nullptr));
    std::vector<std::vector<int>> mat;
    for (int i = 0; i < m; i++) {
        std::vector<int> temp;
        for(int j = 0; j < n; j++)
            temp.push_back(std::rand() % 10);
        mat.push_back(temp);
    }
    return mat;
}

/*
 * Rôle : écrire la matrice passé en paramètre sur la sortie standard
*/
void afficherMatrice(std::vector<std::vector<int>> mat) {
    for (auto x : mat) {
        for (auto y : x)
            std::cout << y << " ";
        std::cout << std::endl;
    }
}


int main () {

    int n = 3, m = 3;

    std::vector<std::vector<int>> mat = initMatrice(m, n);
    afficherMatrice(mat);

    return EXIT_SUCCESS;
}