#include <iostream>
#include <cstdlib>
#include <cstring>


int main () {

    std::string s1, s2;
    s1 = "Bonjour";
    s2 = " à tous";
    char s3 [] = "";

    // écriture sur la sortie standard avec printf
    printf("%s \n", s1.c_str());

    // concaténation avec stract
    strcat(s3, s1.c_str());
    strcat(s3, s2.c_str());
    std::cout << s3 << std::endl;
    
    return EXIT_SUCCESS;
}
