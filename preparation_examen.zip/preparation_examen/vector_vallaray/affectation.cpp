#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>

// A cause de la reutilisabilité du code de l'affichage du vecteur
// on décide de créer une procédure pour réduire cela
void afficherVecteur(std::vector<std::string> v) {
    for (auto x : v) 
        std::cout << x << " ";
    std::cout << std::endl;
}


int main () {

    std::vector<std::string> v1, v2;
    v1 = {"a", "b", "c"};
    // affectation de v1 à v2
    v2 = v1;

    // affichage du contenu de v1 et v2
    afficherVecteur(v1);
    afficherVecteur(v2);

    // Modification de V2[0]
    v2[0] = "d";

    // affichage du contenu de v1
    afficherVecteur(v1);
    afficherVecteur(v2);
    /*  quand on fait l'affecation de v1 à v2 on fait une copie
    Donc en modifiant la valeur du vecteur v2, on ne modifie pas la valeur de v1
    */
    
    return EXIT_SUCCESS;
}