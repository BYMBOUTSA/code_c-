#include <iostream>
#include <cstdlib>
#include <vector>

/*
 * Rôle : afficher le vecteur sur la sortie standard 
*/
void afficherVecteur(std::vector<int> v) {
    for (auto x : v)
        std::cout << x << " ";
    std::cout << std::endl;
}

/*
 * Rôle : initialiser in vecteur v avec les n premières valeurs paires positives
*/
void vecteurPair(std::vector<int> &v, int n) {
    for(int i = 0; i < n; i++)
        v.push_back(i * 2);
}

/*
 * Rôle : Insérer dans un vecteur v qui contient une suite de nombre pair les nombres impairs 
*/
void vecteurPairImpair(std::vector<int> &v) {
    for (int i = 1; i <= v.size(); i += 2)
        v.insert(v.begin() + i, i);
}

/*
 * Rôle : Supprimer du vecteur précédent tous les nombres impairs
*/
void vecteurImpair(std::vector<int> &v) {
    for (int i = 0; i < v.size(); i++) 
        v.erase(v.begin() + i);
}

int main () {

    std::vector<int> v1;
    int n = 6;

    vecteurPair(v1, 6);
    vecteurPairImpair(v1);
    vecteurImpair(v1);

    afficherVecteur(v1);

    return EXIT_SUCCESS;
}