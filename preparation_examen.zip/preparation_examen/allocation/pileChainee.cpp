#include <iostream>
#include <sstream>
#include <cassert>
#include "pileChainee.hpp"

// Méthodes privées

/*
 * Rôle : supprimer le noeud n et les suivants
*/
// 1ère version : récursive
void pileChainee::detruire(noeud *n) {
    // s'il y a encore des noeuds
    if (n != nullptr) {
        detruire(n->getSuivant());
        delete n;
    }
}

// 2ème méthode : itérative
/*void pileChainee::detruire(noeud * n) {
    // tant que la pile n'est pas vide
    while (n != nullptr) {
        // on crée un noeud qui va pointer sur le noeud suivant
        noeud *p = n->getSuivant();
        // on retire le noeud précédent
        delete n;
        // on positionne les pointeurs sur le même noeud
        n = p;
    }
}*/

/*
 * Rôle : duplique le noeud n et les suivants
*/
// 1ère méthode : récursive
noeud * pileChainee::dupliquer(noeud * n) {
    // si la pile est vide
    if (n == nullptr) return nullptr;
    // sinon on copie le noeud suivant
    noeud * p = dupliquer(n->getSuivant());
    // on retourne le nouveau noeud avec sa valeur et son pointeur 
    return new noeud(n->getElement(), p);
}

// 2ème méthode : itérative
/*noeud * pileChainee::dupliquer(noeud * n) {
    if (n == nullptr) return nullptr;
    // création du premier noeud
    noeud * p = new noeud(n->getElement());
    // on positionne les pointeur au même endroit
    noeud * q = p;
    // tant que le noeud suivant ne pointe pas sur nullptr
    while ((n = n->getSuivant()) != nullptr) {
        // on crée un nouveau noeud
        noeud *t = new noeud(n->getElement());
        // on modifie le pointeur suivant
        q->setSuivant(t);
        // on positionne les pointeurs sur le même noeud
        q = t;
    }
    return p;
}*/

// Méthodes publiques

/*
 * Rôle : renvoie true si la pile courante est vide sinon false
*/
bool pileChainee::estVide() const {
    // on teste si le pointeur de sommet pointe sur nullptr
    // si c'est le cas c'est que la pile est vide sinon il y a des éléments
    return (this->sp == nullptr);
}

/*
 * Rôle : ajouter l'élément x en sommet de la pile courante
*/
void pileChainee::empiler(const int x) {
    // création du noeud
    noeud * p = new noeud(x, this->sp);
    // on place le noeud crée en sommet de la pile courante
    this->sp = p;
}

/*
 * Rôle : retirer l'élement en sommet de la pile courante
*/
void pileChainee::depiler() {
    // on vérifie que la pile ne soit pas vide
    assert(!this->estVide());
    // on positionne le pointeur p en sommet de la pile
    noeud * p = this->sp;
    // on déplace le pointeur courant sur l'élément suivant
    this->sp = this->sp->getSuivant();
    // on retire le sommet de la pile (destruction du noeud)
    delete p;
}

/*
 * Rôle : renvoie l'entier en sommet de la pile
*/
int pileChainee::sommet() const {
    // on vérifie que la pile ne soit pas vide
    assert(!this->estVide());
    // on renvoie la valeur du sommet de la pile
    return this->sp->getElement();
}

/*
 * Rôle : renvoie la représentation de l'objet courant sous forme d'une string
*/
// en passant par le flux (ostringstream)
std::string pileChainee::toString() const {
    // initialisation de s
    std::ostringstream s;
    s << "[";
    // on crée un pointeur sur le sommet de la pile
    noeud * n = this->sp;
    // tant que la pile n'est pas vide
    while (n != nullptr) {
        // on met chacun des éléments pointés dans le flux
        s << *n << " ";
        n = n->getSuivant(); // on se positionne sur le noeud suivant 
    }
    // on met le crocher fermant dans le flux
    s << "]";
    // on retourne la chaiîne de caractère représenté par le flux 
    return s.str();
}

// en passant par une string
/*std::string pileChainee::toString() const {
    std::string s = "[";
    noeud * n = this->sp;
    while(n != nullptr) {
        s += std::to_string(n->getElement()) + " ";
        n = n->getSuivant();
    }
    return s + "]";
}*/

/*
 * Rôle : surchargé l'opérateur << sur ostream
*/
std::ostream & operator<<(std::ostream &f, const pileChainee &p) {
    return f << p.toString();
}

/*
 * Rôle :  surchargé l'opérateur d'affectation  
*/
pileChainee & pileChainee::operator=(const pileChainee &p) {
    std::cout << "affectation copie de la pile" << std::endl;
    this->sp = dupliquer(p.sp); // on fait la copie de p dans sp
    return *this; // renvoie le pointeur sur le noeud courant
}