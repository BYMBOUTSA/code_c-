#include <iostream>
#include <sstream>
#include "noeud.hpp"

/*
 * Rôle : renvoie la valeur de l'élément 
*/
int noeud::getElement() const {
    return this->elt;
}

/*
 * Rôle : modifier la valeur de l'élément 
*/
void noeud::setElement(const int e) {
    this->elt = e;
}

/*
 * Rôle : renvoie la valeur de l'élément suivant
*/
noeud * noeud::getSuivant() const {
    return this->suivant;
}

/*
 * Rôle : modifier la valeur de l'élément suivant
*/
void noeud::setSuivant(noeud * s) {
    this->suivant = s;
}

/*
 * Rôle : renvoie la représentation sous forme de std::string de l'objet courant 
*/
// avec l'utilisation du flux (ogstringstream)
std::string noeud::toString() const {
    std::ostringstream s;
    s << this->elt;
    return s.str();
}

// sans l'utilisation du flux 
/*std::string noeud::toString() const {
    std::string s;
    s = std::to_string(this->elt); // écriture de l'élément dans le flux s
    return s; // retourne la conversion de l'ostringstream en chaîne de carctère
}*/

// sans l'utilisation du flux avec l'ajout des crochets dans l'affichage
/*std::string noeud::toString() const {
    std::string s = "[";
    s += std::to_string(this->elt); // écriture de l'élément dans le flux s
    return s + "]"; // retourne la conversion de l'ostringstream en chaîne de carctère
}*/

/*
 * Rôle : surchargé l'opérateur << sur ostream
*/
std::ostream & operator<<(std::ostream &f, const noeud &n) {
    return f << n.toString();
}
