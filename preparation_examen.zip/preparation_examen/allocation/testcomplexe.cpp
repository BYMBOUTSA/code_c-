#include <iostream>
#include <cstdlib>
#include "complexe.hpp"


int main () {

    // exercice 2
    //complexe c1;
    //complexe c1 = complexe (2.1, 6.7);
    // exercice 4
    //complexe c2 = complexe(); // on a une erreur car on a plus de constructeur par default, donc il faut faire l'initialisation en ajoutant des valeurs pour que çà fonctionne correctement

    // 1ere manière de déclaré des variables et initialiser des objets
    complexe c1 = complexe ();
    complexe c2 = complexe (4.5);
    complexe c3 = complexe (3.2, 8.9);

    // 2ème méthode de déclaré des variables et initialiser des objets
    /*complexe c1;
    complexe c2 (4.5);
    complexe c3 (3.2, 8.6);*/

    // Affichage des parties réelles et imaginaires de c1, c2, c3
    /*std::cout << c1.getPreelle() << ", " << c1.getPimg() << std::endl;
    std::cout << c2.getPreelle() << ", " << c2.getPimg() << std::endl;
    std::cout << c3.getPreelle() << ", " << c3.getPimg() << std::endl;*/
    /*c1.ecrireComplexe();
    c2.ecrireComplexe();
    c3.ecrireComplexe();

    // calcul du rho (norme) et theta (argument)
    std::cout << "--- norme et argument ---" << std::endl;
    std::cout << c1.rho() << std::endl;
    std::cout << c2.rho() << std::endl;
    std::cout << c3.rho() << std::endl;

    std::cout << c1.theta() << std::endl;
    std::cout << c2.theta() << std::endl;
    std::cout << c3.theta() << std::endl;

    std::cout << complexe::polComplexe(c2.rho(), c2.theta()) << std::endl;*/

    /*complexe c4 = c1.plus(c2);
    c4.ecrireComplexe();
    complexe c5 = c2.plus(c3);
    c5.ecrireComplexe();

    
    c4.ecrireComplexe();

    c4 = c1.moins(c2);
    c4.ecrireComplexe();
    c5 = c2.moins(c3);
    c5.ecrireComplexe();

    c4 = c1.mult(c2);
    c4.ecrireComplexe();
    c5 = c2.mult(c3);
    c5.ecrireComplexe();

    c4 = c1.div(c2);
    c4.ecrireComplexe();
    c5 = c2.div(c3);
    c5.ecrireComplexe();*/
    
    // Opération en utilisant les surcharges
    std::cout << "--- surcharges des opérateurs ---" << std::endl;
    complexe c4 = c1 + c2;
    c4.ecrireComplexe();
    complexe c5 = c2 + c3;
    c5.ecrireComplexe();

    c4 = c1 - c2;
    c4.ecrireComplexe();
    c5 = c2 - c3;
    c5.ecrireComplexe();

    c4 = c1 * c2;
    c4.ecrireComplexe();
    c5 = c2 * c3;
    c5.ecrireComplexe();

    c4 = c1 / c2;
    c4.ecrireComplexe();
    c5 = c2 / c3;
    c5.ecrireComplexe();

    // test des égalités et des différences
    std::cout << "--- égalités et différences ---" << std::endl;
    std::cout << (c1 == c2) << std::endl;
    std::cout << (c2 == c3) << std::endl;
    std::cout << (c1 == c3) << std::endl;
    std::cout << (c1 != c2) << std::endl;
    std::cout << (c2 != c3) << std::endl;
    std::cout << (c1 != c3) << std::endl;

    // conjugué et écriture sur la sortie standard
    std::cout << "--- conjugué ---" << std::endl;
    c4 = c2.conjugue();
    std::cout << c4 << std::endl;
    c5 = c3.conjugue();
    std::cout << c5 << std::endl;


    // TD5 (allocation)
    int * pi = new int[10];
    complexe * pc = new complexe[5];
    complexe *pc0 = new complexe(3.1, 6.56);
 
    // affectation de la valeur 10 au 2ème élément de pi
    pi[1] = 10;
    std::cout << pi[1] << std::endl;

    // affichage de la valeur de pi[8]
    std::cout << pi[8] << std::endl; // c'est égal à 0, que lors de l'aalocation, on alloue chacune des valeurs du tableau à 0

    // affichage de la valeur de pi[11]
    std::cout << pi[11] << std::endl; // C'est égal à 0, qu'on ne maîtrise pas les indices lors de l'allocation, donc on peut accéder à des indices qui n'appartiennnent pas aux indices du tableau

    // affichage de la valeur du 3ème éléments de pc
    pc[2].ecrireComplexe(); // que çà partie réélle est à 0 ainsi que sa partie imaginaire, l'initialisation ce fait à 0 

    // oui, le constructeur par défaut est obligatoire car l'objet est initialisé à 0, lors de l'allocation

    // allocation d'un tableau de 10 pointeurs sur complexe
    complexe **ptpc = new complexe *[10];
    // affichage du deuxième élement de ce tableau
    //std::cout << *ptpc[1] << std::endl; // erreur de segmentation si j'essaie de récupérer çà ainsi
    // passage par une boucle for
    for (int i = 0; i < 10; i++) {
        ptpc[i] = new complexe();
    }
    // affichege du deuxième éléments
    (*ptpc[1]).ecrireComplexe(); // partie réelle à 0 et imaginaire à 0, car en faisant l'allocation on alloue tous à 0 si ça n'a pas été modidié à la main

    // destruction du complexe pc0(3.1, 6.56)
    delete pc0;

    // Oui le destructeur est bien exécuté
    // affichage de la partie imaginaire de pc0
    //std::cout << pc0->getPimg() << std::endl; // on a une valeur par défaut pendant qu'on était sensé avoir un message d'erreur car on ne sait d'accéder à quelque chose qui n'existe pas en mémoire (fuite de mémoire) ou encore parce qu'il y a un manque de contrôle

    // destruction des éléments du tableau pc
    delete [] pc; // oui il est bien exécuté pour chacun des élémentd du tableau

    // destruction des éléments du ytableau ptpc
    delete [] ptpc; // oui il est bien appelé pour chacun des éléments du tableau, parce que le destructeur est appelé chaque fois qu'on supprime un élément du tableau

    complexe c6(1.2, 56.9);
    std::cout << "c6 = " << c6 << std::endl; // qu'il affiche bien sur la sortie standard la partie réelle et imaginaire de c6, qu'il utilise bien comme il se doit toute les propriétés de l'objet complexe
    // donc on peut directement écrire le complexe sur la sortie standard sans devoir utiliser la méthode ecrireComplexe, et celle toString


    return EXIT_SUCCESS;
}