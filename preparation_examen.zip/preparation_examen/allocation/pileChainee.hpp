#pragma once
#include <iostream>
#include "noeud.hpp"


class pileChainee {
    private:
        noeud *sp; // le sommet de la pile
        // méthode pour supprimer tous les éléments de liste de noeuds n
        void detruire(noeud * n); 
        // méthode pour dupliquer tous les éléments de liste de noeuds n
        noeud * dupliquer(noeud * n);
    public:
        pileChainee(noeud *s = nullptr) : sp(s) {}
        // constructeur de copie
        pileChainee(const pileChainee &p) {
            this->sp = this->dupliquer(p.sp);
        }
        ~pileChainee() {
            std::cout << "Destruction de la pile" << std::endl;
            this->detruire(this->sp);
        }
        bool estVide() const;
        void empiler(const int x);
        int sommet() const;
        void depiler();
        std::string toString() const;
        friend std::ostream & operator<<(std::ostream &f, const pileChainee &p);
        pileChainee & operator=(const pileChainee & p);

};