#include <iostream>
#include <cstdlib>
#include "pileChainee.hpp"


// ajout de la fonction ecrirePile qui écrit sur la sortie standard le contenu d'une pile p passée en paramètre
/*
 * Rôle : écrire sur la sortie standard le contenue d'une pile p passée en paramètre 
*/
void ecrirePile(const pileChainee p) {
    std::cout << p << std::endl;
}

int main () {

    pileChainee p = pileChainee();
    std::cout << p.estVide() << std::endl;
    p.empiler(6);
    p.empiler(15);
    std::cout << p.sommet() << std::endl;
    std::cout << p.estVide() << std::endl;
    std::cout << p.sommet() << std::endl;
    p.depiler();
    std::cout << p.sommet() << std::endl;

    // oui, il est exécuté mais il ne supprime pas tous les éléments de la pile 

    // test de l'affichage du noeud
    /*std::cout << "--- teste du fonctionnement du noeud ---" << std::endl;
    noeud n = noeud(2);
    std::cout << n << std::endl; // teste de la surcharge car j'écris le noeud directement sur la sortie standard
    noeud s = noeud(3);
    noeud * t;
    std::cout << n <<  " " << s << std::endl; 
    std::cout << n.getElement() << std::endl; // teste de getElement()
    std::cout << n.getSuivant() << std::endl; // teste de getSuivant()
    std::cout << s.getElement() << std::endl;
    std::cout << s.getSuivant() << std::endl;
    n.setElement(7); // teste de setElement()
    std::cout << n.getElement() << std::endl;
    s.setElement(9);
    std::cout << s.toString() << std::endl; // teste de toString() 
    n.setSuivant(t); // utilisation de setSuivant()
    std::cout << n.getSuivant() << std::endl;*/



    // déclaration d'une variable p1 de type pileChainee
    pileChainee p1 = pileChainee ();
    // empiler la valeur 1 en sommet de la pile p1, afficher la valeur du sommet
    p1.empiler(10);
    std::cout << p1.sommet() << std::endl;

    // déclaration de la pile p2 initialisée à p1
    //pileChainee p2 = p1;
    // affichage de la valeur du sommet de p2
    //std::cout << p2.sommet() << std::endl;
    // dépilage sur p2, et affichage du sommet de p1, puis celle de p1
    //p2.depiler();
    //std::cout << p1.sommet() << std::endl; // erreur de segmentation et valeur par defaut si on a les deux instructions
    //std::cout << p2.sommet() << std::endl; // assertion
    // on constate qu'on a une segmentation erreur pourtant on a dépiler p2 et non p1 donc on a pas juste fait une copie
    // mais en faisant l'affectation on a affecter p1 à p2 donc nous n'avons plus qu'une seule pile avec deux noms

    // après avoir rédefinis le constructeur de copie on voit bien maintenant que la déclaration pileChainee p2 = p1 fonctionne bien correctement

    // Affectation suivi de la copie après avoir fait la surcharge de l'operateur = 
    pileChainee p2;
    p2 = p1;
    std::cout << p2.sommet() << std::endl;
    /*p2.depiler();
    std::cout << p1.sommet() << std::endl;
    std::cout << p2.sommet() << std::endl;*/
    // on voit bien qu'après avoir fait la surcharge de l'opérateur = en dépilant le sommet de la pile p2 on ne dépile pas le sommet de la pile p1
    // donc on a bien éffectué en faisant p2 = p1 une simple copie du contenu de la pile 1 dans la pile 2, alors la copie à belle et bien eu lieu

    ecrirePile(p1);

    return EXIT_SUCCESS;
}