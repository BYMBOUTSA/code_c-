#include <iostream>
#include <cstdlib>
#include "complexe.hpp"


/*int main () {

    int * pi = new int[10];
    complexe * pc = new complexe[5];
    complexe *pc0 = new complexe(3.1, 6.56);
 
    // affectation de la valeur 10 au 2ème élément de pi
    pi[1] = 10;
    std::cout << pi[1] << std::endl;

    // affichage de la valeur de pi[8]
    std::cout << pi[8] << std::endl; // c'est égal à 0, que lors de l'aalocation, on alloue chacune des valeurs du tableau à 0

    // affichage de la valeur de pi[11]
    std::cout << pi[11] << std::endl; // C'est égal à 0, qu'on ne maîtrise pas les indices lors de l'allocation, donc on peut accéder à des indices qui n'appartiennnent pas aux indices du tableau

    // affichage de la valeur du 3ème éléments de pc
    pc[2].ecrireComplexe(); // que çà partie réélle est à 0 ainsi que sa partie imaginaire, l'initialisation ce fait à 0 

    // oui, le constructeur par défaut est obligatoire car l'objet est initialisé à 0, lors de l'allocation

    // allocation d'un tableau de 10 pointeurs sur complexe
    complexe **ptpc = new complexe *[10];
    // affichage du deuxième élement de ce tableau
    //std::cout << *ptpc[1] << std::endl; // erreur de segmentation si j'essaie de récupérer çà ainsi
    // passage par une boucle for
    for (int i = 0; i < 10; i++) {
        ptpc[i] = new complexe();
    }
    // affichege du deuxième éléments
    (*ptpc[1]).ecrireComplexe(); // partie réelle à 0 et imaginaire à 0, car en faisant l'allocation on alloue tous à 0 si ça n'a pas été modidié à la main

    // destruction du complexe pc0(3.1, 6.56)
    delete pc0;

    // Oui le destructeur est bien exécuté
    // affichage de la partie imaginaire de pc0
    //std::cout << pc0->getPimg() << std::endl; // on a une valeur par défaut pendant qu'on était sensé avoir un message d'erreur car on ne sait d'accéder à quelque chose qui n'existe pas en mémoire (fuite de mémoire) ou encore parce qu'il y a un manque de contrôle

    // destruction des éléments du tableau pc
    delete [] pc;

    return EXIT_SUCCESS;
}*/