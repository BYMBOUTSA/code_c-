#include <iostream>
#include <cstdlib>
#include "complexe.hpp"


int main () {

    // exercice 2
    //complexe c1;
    //complexe c1 = complexe (2.1, 6.7);
    // exercice 4
    //complexe c2 = complexe(); // on a une erreur car on a plus de constructeur par default, donc il faut faire l'initialisation en ajoutant des valeurs pour que çà fonctionne correctement

    // 1ere manière de déclaré des variables et initialiser des objets
    /*complexe c1 = complexe ();
    complexe c2 = complexe (4.5);
    complexe c3 = complexe (3.2, 8.9);*/

    // 2ème méthode de déclaré des variables et initialiser des objets
    complexe c1;
    complexe c2 (4.5);
    complexe c3 (3.2, 8.6);

    // Affichage des parties réelles et imaginaires de c1, c2, c3
    /*std::cout << c1.getPreelle() << ", " << c1.getPimg() << std::endl;
    std::cout << c2.getPreelle() << ", " << c2.getPimg() << std::endl;
    std::cout << c3.getPreelle() << ", " << c3.getPimg() << std::endl;*/
    c1.ecrireComplexe();
    c2.ecrireComplexe();
    c3.ecrireComplexe();

    // calcul du rho (norme) et theta (argument)
    std::cout << "--- norme et argument ---" << std::endl;
    std::cout << c1.rho() << std::endl;
    std::cout << c2.rho() << std::endl;
    std::cout << c3.rho() << std::endl;

    std::cout << c1.theta() << std::endl;
    std::cout << c2.theta() << std::endl;
    std::cout << c3.theta() << std::endl;

    std::cout << complexe::polComplexe(c2.rho(), c2.theta()) << std::endl;

    /*complexe c4 = c1.plus(c2);
    c4.ecrireComplexe();
    complexe c5 = c2.plus(c3);
    c5.ecrireComplexe();

    
    c4.ecrireComplexe();

    c4 = c1.moins(c2);
    c4.ecrireComplexe();
    c5 = c2.moins(c3);
    c5.ecrireComplexe();

    c4 = c1.mult(c2);
    c4.ecrireComplexe();
    c5 = c2.mult(c3);
    c5.ecrireComplexe();

    c4 = c1.div(c2);
    c4.ecrireComplexe();
    c5 = c2.div(c3);
    c5.ecrireComplexe();*/
    
    // Opération en utilisant les surcharges
    std::cout << "--- surcharges des opérateurs ---" << std::endl;
    complexe c4 = c1 + c2;
    c4.ecrireComplexe();
    complexe c5 = c2 + c3;
    c5.ecrireComplexe();

    c4 = c1 - c2;
    c4.ecrireComplexe();
    c5 = c2 - c3;
    c5.ecrireComplexe();

    c4 = c1 * c2;
    c4.ecrireComplexe();
    c5 = c2 * c3;
    c5.ecrireComplexe();

    c4 = c1 / c2;
    c4.ecrireComplexe();
    c5 = c2 / c3;
    c5.ecrireComplexe();

    // test des égalités et des différences
    std::cout << "--- égalités et différences ---" << std::endl;
    std::cout << (c1 == c2) << std::endl;
    std::cout << (c2 == c3) << std::endl;
    std::cout << (c1 == c3) << std::endl;
    std::cout << (c1 != c2) << std::endl;
    std::cout << (c2 != c3) << std::endl;
    std::cout << (c1 != c3) << std::endl;

    // conjugué et écriture sur la sortie standard
    std::cout << "--- conjugué ---" << std::endl;
    c4 = c2.conjugue();
    std::cout << c4 << std::endl;
    c5 = c3.conjugue();
    std::cout << c5 << std::endl;

    return EXIT_SUCCESS;
}