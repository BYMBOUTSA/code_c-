#include <iostream>
#include <cstdlib>
#include <ctime>
#include "tableau.hpp"
#include "indexException.hpp"

int main () {

    const int nbElems = 10;
    const int valMax = 1000;

    // déclaration du tableau
    tableau<nbElems, int> t;
    // on initialise le tableau de façon aléatoire
    std::srand(std::time(nullptr));
    for (int i = 0; i < t.longueur(); i++) 
        t[i] = rand() % valMax;
    // affichage des valeurs sur la sortie standard
    std::cout << t << std::endl;

    bool ok = false;
    do {
        int i;
        // lire un indice sur l'E/S
        std::cout << "i = "; std::cin >> i;
        try {
            // afficher l'élément t[i]
            std::cout << t[i] << std::endl;
            ok = true;
        }
        catch (const IndexException & e) {
            std::cerr << e.what() << ", Recommencez. " << std::endl;
        }

    } while(!ok);


    return EXIT_SUCCESS;
}
