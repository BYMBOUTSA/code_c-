#include <iostream>
#include <cstdlib>
#include <string>
#include <exception>

class MonException1 : public std::exception {
    public:
        virtual const char * what() const noexcept override{
            return "MonException1";
        }
        friend std::ostream & operator<<(std::ostream &f, const MonException1 e) {
            return f << e.what();
        }

};


class MonException2 : public MonException1 {
    public:
        virtual const char * what() const noexcept override {
            return "MonException2";
        }
        friend std::ostream& operator<<(std::ostream &f, const MonException2 &e) {
            return f << e.what();
        }

};


void f() {
    throw MonException1();
}

void g() {
    throw MonException2();
}

int main () {
    try {
        //g();
        f();
        g();
    }
    // on doit les mettre du particulier au général donc de l'exception 2 à l'exception 1 car il y a une rélation d'héritage entre eux
    catch(MonException2 & e) {
        std::cerr << "Exception 2" << std::endl;
    }
    catch(MonException1 & e) {
        std::cerr << "Exception 1" << std::endl;
    }
    
    

    return EXIT_SUCCESS;
}