#pragma once
#include <iostream>


class complexe {
    private:
        double preelle;
        double pimg;
    public:
        static const complexe I;
        complexe(const double r = 0.0, const double i = 0.0) : preelle(r), pimg(i) {}
        ~complexe() {
            //std::cout << "Je suis le destructeur de complexes !" << std::endl;
        }
        double getPreelle() const;
        void setPreelle(const double r);
        double getPimg() const;
        void setPimg(const double i);
        std::string toString() const;
        void ecrireComplexe();
        double rho() const;
        double theta() const;
        static complexe polComplexe(const double rho, const double theta);
        complexe plus(const complexe &c) const;
        complexe moins(const complexe &c) const;
        complexe mult(const complexe &c) const;
        complexe div(const complexe &c) const;
        bool egal(const complexe &c) const;
        bool different(const complexe &c) const;
        complexe operator+(const complexe &c) const;
        complexe operator-(const complexe &c) const;
        complexe operator*(const complexe &c) const;
        complexe operator/(const complexe &c) const;
        complexe operator==(const complexe &c) const;
        complexe operator!=(const complexe &c) const;
        complexe conjugue() const;
        complexe operator~() const;
        friend std::ostream & operator<<(std::ostream& f, const complexe &c);
};