#pragma once
#include <iostream>
#include <initializer_list>
#include <sstream>
#include "indexException.hpp"


template <int N, typename T>

class tableau {
    private:
        T elem[N];
    public:
        // constructeur pour initialiser les valeurs du tableau à une valeur v
        tableau(const T & v = T()) {
            for (int i = 0; i < N; i++) this->elem[i] = v;
        }
        // constructeur pour initialiser toute les valeurs du tableau à une liste l
        tableau(const std::initializer_list<T> &l) {
            int i = 0;
            for (auto x : l) (*this)[i++] = x;
            // si c'est incomplet, on initialise le reste du tableau à T()
            for (; i < N; i++) this->elem[i] = T();
        }
        // constructeur de copie
        tableau(const tableau<N, T> &t) {
            for (int i = 0; i < N; i++) this->elem[i] = t->elem[i];
        }
        /*
         * Rôle : renvoie la longueur de l'objet courant
        */
        int longueur() const {
            return N;
        }
        /*
         * Rôle : surchargé l'opérateur [], renvoie une référence sur t[i]
        */
        T & operator[](const int i) {
            if (i < 0) throw IndexUnderFlow(i);
            if (i >= N) throw IndexOverFlow(i);
            // i est un indice valide de [1, N-1]
            return this->elem[i];
        }
        /*
         * Rôle : renvoie la représentation en std::string de l'objet courant
        */
        std::string toString() const {
            std::ostringstream s;
            s << "[";
            for (auto x : this->elem) 
                s << x << " ";
            s << "]";
            return s.str();
        }

        /*
         * Rôle : surchargé l'opérateur << sur un ostream
        */
        friend std::ostream & operator<<(std::ostream &f, const tableau<N, T> &t) {
            return f << t.toString();
        }

};

