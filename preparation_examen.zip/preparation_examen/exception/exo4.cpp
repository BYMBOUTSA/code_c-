#include <iostream>
#include <cstdlib>
#include <string>


class MonException {
    public:
        std::string toString() const {
            return "MonException";
        }
        friend std::ostream & operator<<(std::ostream &f, const MonException &e) {
            return f << e.toString();
        }
};


void f() {
    throw 1; // modification de f() pour qu'elle émette un message d'un autre type
    //throw MonException();
    // on a bien l'arrêt du programme avec le message 
    // terminate called after throwing an instance of 'int'
}

void g() {
    try {
        f();
        std::cout << "g : après f()" << std::endl;
    }
    catch(MonException &e) {
        std::cerr << "Exception : MonException attrapée dans g" << std::endl;
        throw; // on l'a ajouter pouvoir ajouter le message du catch du main en plus de celui de g
    }
    std::cout << "g : après catch" << std::endl;
}


void finir() {
    std::cerr << "C'est fini, adieu!" << std::endl;
}

int main () {
    std::set_terminate(finir);
    try {
        g();
        std::cout << "Main : après g()" << std::endl;
    }
    catch(MonException & e) {
        std::cerr << "Exception : MonException attrapée dans main" << std::endl;
    }
    std::cout << "Main : après catch" << std::endl;

    return EXIT_SUCCESS;
}