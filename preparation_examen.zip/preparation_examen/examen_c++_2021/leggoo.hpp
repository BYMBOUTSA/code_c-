#pragma once
#include <iostream>
#include "produit.hpp"


class leggoo : public produit {
    protected:
        int age;
    public:
        leggoo(const double p, const int a = 6) : produit(p), age(a) {}
        int getAge() const;
        virtual std::string toString() const override;
        virtual void ecrireProduit(std::ofstream &f) const override;
};