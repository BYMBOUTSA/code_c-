#include <iostream>
#include <sstream>
#include <fstream>
#include "leggoo.hpp"

/*
 * Rôle : renvoie l'âge de l'objet courant 
*/
int leggoo::getAge() const {
    return this->age;
}

/*
 * Rôle : renvoie la représentation en std::string de l'objet courant
*/
std::string leggoo::toString() const {
    std::ostringstream s;
    s << "Leggoo - pour âges " << this->age << "+ - ";
    s << produit::prixToString();
    return s.str();
}

/*
 * Rôle : écrire le produit courant dans un fichier 
*/
void leggoo::ecrireProduit(std::ofstream &f) const {
    f.write((char *) this, sizeof(leggoo));
}