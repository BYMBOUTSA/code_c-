#pragma once
#include <iostream>
#include <string>
#include <exception>

class FileException : public std::exception {
    private:
        std::string msg;
    public:
        FileException(const std::string &e) : msg(e) {}
        virtual const char * what() const noexcept override {
            return msg.c_str();
        }
};