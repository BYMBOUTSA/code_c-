#pragma once
#include <iostream>
#include <sstream>


class produit {
    protected:
        double prix;
        double tauxReduction = 1.0;
        std::string prixToString() const {
            std::ostringstream s;
            if (this->getTaux() != 1.0)
                s << "soldé à ";
            s << this->getPrix() << " euros" << std::endl;
            return s.str();
        }
    public:
        produit(const double pr) : prix(pr) {}
        virtual ~produit() {
            std::cout << "Destruction du produit" << std::endl;
        }
        double getPrix() const;
        double getTaux() const;
        void setTaux(const double taux);
        // toString méthode abstraite
        virtual std::string toString() const = 0;
        friend std::ostream & operator<<(std::ostream &f, const produit &p);
        virtual void ecrireProduit(std::ofstream &f) const = 0;
        friend std::ofstream & operator<<(std::ofstream &f, const produit &p);
};