#pragma once
#include <iostream>
#include <string>
#include "produit.hpp"


class pull : public produit {
    protected:
        std::string couleur;
    public:
        pull(const double p, const std::string c) : produit(p), couleur(c) {}
        std::string getCouleur() const;
        virtual std::string toString() const override;
        virtual void ecrireProduit(std::ofstream &f) const override;
};