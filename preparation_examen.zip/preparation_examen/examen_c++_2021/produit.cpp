#include <iostream>
#include <cassert>
#include "produit.hpp"

/*
 * Rôle : renvoie le prix de l'objet courant 
*/
double produit::getPrix() const {
    return this->prix * getTaux();
}

/*
 * Rôle : renvoie le taux de reduction de l'objet courant
*/
double produit::getTaux() const {
    return this->tauxReduction;
}

/*
 * Rôle : modifier le taux de reduction de l'objet courant 
*/
void produit::setTaux(const double taux) {
    assert(taux >= 0 && taux <= 1.0);
    this->tauxReduction = taux;
}

/*
 * Rôle : surchargé l'opérateur << sur un ostream 
*/
std::ostream & operator<<(std::ostream &f, const produit &p) {
    return f << p.toString();
}

/*
 * Rôle : surchargé l'opérateur << pour écrire dans un fichier
*/
std::ofstream & operator<<(std::ofstream &f, const produit &p) {
    p.ecrireProduit(f);
    return f;
}