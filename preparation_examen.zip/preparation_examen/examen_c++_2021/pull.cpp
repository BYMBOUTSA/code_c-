#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include "pull.hpp"

/*
 * Rôle : renvoie la couleur de l'objet courant
*/
std::string pull::getCouleur() const {
    return this->couleur;
}
std::string pull::toString() const {
    std::ostringstream s;
    s << "Pull - " << this->couleur << " - ";
    s << produit::prixToString();
    return s.str();
}


/*
 * Rôle : écrire le produit courant dans un fichier
*/
void pull::ecrireProduit(std::ofstream &f) const {
    f.write((char *) this, sizeof(pull));
}
