#include <iostream>
#include <cstdlib>
#include "produit.hpp"
#include "leggoo.hpp"
#include "pull.hpp"
#include "listeDeCourses.hpp"
#include "FileException.hpp"


int main () {

    ListeDeCourses MarioListe, PecheListe;

    // liste de Mario
    produit * p = new leggoo(90.0, 12);
    p->setTaux(0.5);
    MarioListe.ajouter(p);
    p = new leggoo(70.0);
    p->setTaux(0.7);
    MarioListe.ajouter(p);
    MarioListe.ajouter(new pull(40.0, "rouge"));

    // liste de Princess Pêche
    PecheListe.ajouter(new pull(40.0, "magenta"));
    p = new pull(55.0, "rainbow");
    p->setTaux(0.5);
    PecheListe.ajouter(p);
    PecheListe.ajouter(new leggoo(10, 8));

    // affichage des deux listes avce leur prix total
    std::cout << "MarioListe : " << std::endl << MarioListe;
    std::cout << "PêcheListe : " << std::endl << PecheListe;

    // exception
    try {
        MarioListe.enregistrer("/usr/Mario");
    }  
    catch (const FileException & e) {
        std::cerr << e.what() << std::endl;
    }  

    return EXIT_SUCCESS;
}