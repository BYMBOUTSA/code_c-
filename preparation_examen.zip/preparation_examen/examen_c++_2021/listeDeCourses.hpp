#pragma once
#include <iostream>
#include <vector>
#include "produit.hpp"


class ListeDeCourses {
    protected:
        std::vector<produit *> listeCourses;
    public:
        ListeDeCourses() {}
        ~ListeDeCourses() {
            for (produit * p : this->listeCourses)
                delete p;
        }
        void ajouter(produit * p);
        double prixTotal() const;
        std::string toString() const;
        friend std::ostream & operator<<(std::ostream &f, const ListeDeCourses &l);
        void enregistrer(const std::string & filename) const;

};