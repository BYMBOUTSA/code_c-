#include <iostream>
#include <sstream>
#include <vector>
#include <fstream>
#include "FileException.hpp"
#include "listeDeCourses.hpp"

/*
 * Rôle : ajouter un produit dans l'objet courant
*/
void ListeDeCourses::ajouter(produit * p) {
    // ajout du produit p dans la liste de courses
    this->listeCourses.push_back(p);
}

/*
 * Rôle : renvoie le prix total de l'objet courant
*/
double ListeDeCourses::prixTotal() const {
    double total = 0;
    for (produit * p : this->listeCourses)
        total += p->getPrix();
    return total;
}

/*
 * Rôle : renvoie la représentation de l'objet courant en std::string 
*/
std::string ListeDeCourses::toString() const {
    std::ostringstream s;
    for (produit * p : this->listeCourses)
        s << *p << "\n";
    s << "-----------------------\n";
    s << "Total : " << this->prixTotal() << " euros\n";
    s << "------------------------\n";
    return s.str();
}

/*
 * Rôle : surchargé l'opérateur << sur un ostream 
*/
std::ostream & operator<<(std::ostream &f, const ListeDeCourses &l) {
    return f << l.toString();
}

/*
 * Rôle : écrire les produits d'une listeDeCourses courantes dans un fichier
*/
void ListeDeCourses::enregistrer(const std::string & filename) const {
    std::ofstream oos(filename);
    // on vérifie la bonne ouverture du fichier
    if (!oos.is_open()) 
        throw FileException("Erreur : " + filename + " ouverture impossible");
    // si le fichier est correctement ouvert on écrit la liste de produits
    for (produit *p : this->listeCourses)
        oos << *p;
    // fermeture du fichier
    oos.close();
}