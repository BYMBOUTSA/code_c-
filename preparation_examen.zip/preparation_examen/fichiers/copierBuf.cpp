#include <iostream>
#include <cstdlib>
#include <fstream>

/*
 * Rôle : copier le contenu du fichier d'entrée dans un fichier de sortie par blocs de BUFSIZ caractères
*/
void copierBuf(std::string cible, std::string source) {
    // Ouverture des fichiers
    std::ifstream ios(cible);
    std::ofstream oos(source);

    // Vérification de l'ouverture du fichier d'entrée en lecture
    if (!ios.is_open()) {
        perror(cible.c_str());
        exit(EXIT_FAILURE);
    }

    // Vérification de l'ouverture du fichier de sortie en écriture
    if (!oos.is_open()) {
        perror(source.c_str());
        exit(EXIT_FAILURE);
    }

    // Fichiers correctement ouverts
    // faire la copie
    char buf[BUFSIZ];

    // tant qu'il y a un bloc de carctère à lire
    while (ios.read(buf, BUFSIZ))
        oos.write(buf, BUFSIZ); // écriture du bloc de carcatère dans le fichier de sortie
    oos.write(buf, ios.gcount()); // écriture du nombre de bloc de caractère lu
}


int main () {

    std::string in, out;

    std::cout << "Fichier d'entrée : ";
    std::cin >> in;
    std::cout << "Fichier de sortie : ";
    std::cin >> out;

    copierBuf(in, out);

    return EXIT_SUCCESS;
}