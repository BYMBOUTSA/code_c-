#include <iostream>
#include <cstdlib>
#include <iomanip>


int main () {

    double n;
    std::cout << "Entrer un réel : ";
    std::cin >> n;
    std::cout << n << std::endl;
    std::cout << "The number n in scientific : " << std::scientific << n << std::endl;
    std::cout << "The number n in fixed : " << std::fixed << n << std::endl;
    std::cout << "The number n in hexfloat : " << std::hexfloat << n << std::endl;
    std::cout << "The number n in showpoint : " << std::showpoint << n << std::endl;
    std::cout << "The number n in noshowpoint : " << std::noshowpoint << n << std::endl;
    std::cout << "The number n in showpos : " << std::showpos << n << std::endl;
    std::cout << "The number n in noshowpos : " << std::noshowpos << n << std::endl;
    std::cout << "The number n in setprecision : " << std::setprecision(n) << n << std::endl;

    return EXIT_SUCCESS;
}