#include <iostream>
#include <cstdlib>
#include <fstream>
#include "complexe.hpp"

int main () {

    int n;
    std::cout << "Entrer un nombre n : ";
    std::cin >> n;
    std::cout << n << std::endl;
    std::cout << "The number n in octal: " << std::oct << n << std::endl;
    std::cout << "The number n in decimal: " << std::dec << n << std::endl;
    std::cout << "The number n in hex: " << std::hex << n << std::endl;

    // Teste des manipulateurs sur le flux d'entrée standard
    std::cin >> std::oct >> n;
    //std::cout << n << std::endl;
    std::cin >> std::dec >> n;
    std::cin >> std::hex >> n;
    // Il n'agit pas sur le flux d'entrée

    return EXIT_SUCCESS;
}