#include <iostream>
#include <cstdlib>
#include <iomanip>

int main () {

    const double pi = 3.141592653;
    const int n = 30;

    // la barre du haut
    std::cout << std::setfill('-'); // on remplit l'espace avec les tirets (-)
    std::cout << "+" << std::setw(n / 2) << "+" << std::setw(n / 2) << "+" << std::endl; // on réaliser un cadrage sur n / 2
    // la barre du milieu
    std::cout << std::setfill(' ');
    std::cout << '|' << std::setw(n / 2 - 1) << "pi"; // right par défault
    std::cout << '|' << std::setw(n / 2 - 1) << std::left
                << std::setprecision(4) << pi << "|" << std::endl;
    // la barre du bas
    std::cout << std::setfill('-') << std::right; // cadrage à droite
    std::cout << "+" << std::setw(n / 2) << "+" << std::setw(n / 2) << "+" << std::endl;
    
    return EXIT_SUCCESS;
}