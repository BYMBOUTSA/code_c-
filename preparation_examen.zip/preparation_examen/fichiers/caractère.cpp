#include <iostream>
#include <cstdlib>

int main () {
    char c;
    while (std::cin.get(c))
        std::cout.put(c);
        // eof
    return EXIT_SUCCESS;
}