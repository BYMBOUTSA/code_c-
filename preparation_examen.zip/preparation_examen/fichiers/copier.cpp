#include <iostream>
#include <cstdlib>
#include <fstream>

/*
 * Rôle : copier le contenu du fichier d'entrée sur le fichier de sortie
*/
void copier(std::string cible, std::string source) {
    // Ouverture des fichiers
    std::ifstream ios(cible);
    std::ofstream oos(source);

    // Vérification de l'ouverture du fichier d'entrée en lecture
    if (!ios.is_open()) {
        perror(cible.c_str());
        exit(EXIT_FAILURE);
    }

    // Vérification de l'ouverture du fichier de sortie en écriture
    if (!oos.is_open()) {
        perror(source.c_str()); // il faut faire la conversion car perror prend un paramètre const char *
        exit(EXIT_FAILURE);
    }

    // Fichiers correctement ouverts
    // faire la copie
    char c;
    // tant qu'il y a un caractère dans le fichier d'entrée
    while (ios.get(c))
        oos.put(c); // on écrit le carcatère dans le fichier de sortie
    // fermeture des fichiers
    ios.close();
    oos.close();
}

int main () {

    std::string in, out;

    std::cout << "Fichier d'entrée : ";
    std::cin >> in;
    std::cout << "Fichier de sortie : ";
    std::cin >> out;

    copier(in, out);

    return EXIT_SUCCESS;
}