#include <iostream>
#include <cmath>
#include <string>
#include "complexe.hpp"
#include <fstream>

const complexe complexe::I(0, 1);

/*
 * Rôle : renvoie la partie réelle du complexe courant 
*/
double complexe::getPreelle() const {
    return this->preelle;
}

/*
 * Rôle : affecte r à la partie réelle du complexe courant 
*/
void complexe::setPreelle(const double r) {
    this->preelle = r;
}

/*
 * Rôle : renvoie la partie imaginaire du complexe courant 
*/
double complexe::getPimg() const {
    return this->pimg;
}

/*
 * Rôle : affecte i à la partie imaginaire du complexe courant 
*/
void complexe::setPimg(const double i) {
    this->pimg = i;
}

/*
 * Rôle : convertit l'objet courant sous forme d'une chaîne de caractères au format (r, i)
*/
std::string complexe::toString() const {
    return "(" + std::to_string(this->preelle) + ", " + std::to_string(this->pimg) + ")";
}

/*
 * Rôle : écrire sur la sortie standard le complexe courant
*/
void complexe::ecrireComplexe() {
    std::cout << this->toString() << std::endl;
}

/*
 *  Rôle : lire la partie réelle et imaginaire 
*/
void complexe::lireComplexe(std::istream &f) {
    double a, b;
    f >> a >> b;
    complexe d(a, b);
    std::cout << d << std::endl;
}

/*
 * Rôle : renvoie la norme de l'objet courant à la classe complexe
*/
double complexe::rho() const {
    return sqrt(this->preelle * this->preelle + this->pimg * this->pimg);
}

/*
 * Rôle : renvoie l'argument d'un complexe 
*/
double complexe::theta() const {
    return atan2(this->pimg, this->preelle);
}

/*
 * Rôle : renvoie un objet de type complexe en coordonnées cartésiennes 
*/
complexe complexe::polComplexe(const double rho, const double theta) {
    return complexe(rho * cos(theta), rho* sin(theta));
}

/*
 * Rôle : renvoie this + c
*/
complexe complexe::plus(const complexe &c) const {
    return complexe(this->preelle + c.preelle, this->pimg + c.pimg);
}

/*
 * Rôle : surcharge de l'opérateur +
*/
complexe complexe::operator+(const complexe &c) const {
    return this->plus(c);
}

/*
 * Rôle : renvoie this - c 
*/
complexe complexe::moins(const complexe &c) const {
    return complexe(this->preelle - c.preelle, this->pimg - c.pimg);
}

/*
 * Rôle : surcharge de l'opérateur -
*/
complexe complexe::operator-(const complexe &c) const {
    return this->moins(c);
}

/*
 * Rôle : renvoie this * c
*/
complexe complexe::mult(const complexe &c) const {
    return complexe::polComplexe(this->rho() * c.rho(), this->theta() + c.theta());
}

/*
 * Rôle : surcharge de l'opérateur *
*/
complexe complexe::operator*(const complexe &c) const {
    return this->mult(c);
}

/*
 * Rôle : renvoie this / c
*/
complexe complexe::div(const complexe &c) const {
    return complexe::polComplexe(this->rho() / c.rho(), this->theta() - c.theta());
}

/*
 * Rôle : surcharge de l'opérateur /
*/
complexe complexe::operator/(const complexe &c) const {
    return this->div(c);
}

/*
 * Rôle : tester si this == c
*/
bool complexe::egal(const complexe &c) const {
    return (this->preelle == c.preelle && this->pimg == c.pimg);
}

/*
 * Rôle : surcharge de l'opérateur ==
*/
complexe complexe::operator==(const complexe &c) const {
    return this->egal(c);
}

/*
 * Rôle : tester si this != c
*/
bool complexe::different(const complexe &c) const {
    return !this->egal(c);
}

/*
 * Rôle : surcharge de l'opérateur !=
*/
complexe complexe::operator!=(const complexe &c) const {
    return this->different(c);
}

/*
 * Rôle : renvoie le conjugué du complexe courant
*/
complexe complexe::conjugue() const {
    return complexe(this->preelle, -this->pimg);
}

complexe complexe::operator~() const {
    return this->conjugue();
}

/*
 * Rôle : surchargé l'opérateur << en écriture au format binaire
*/
/*std::ofstream & operator<<(std::ofstream &f, const complexe &c) {
    f.write((char *) &c, sizeof(complexe));
    return f;
}*/

/*
 * Rôle surchargé l'opérateur >> en lecture au format binaire
*/
/*std::ifstream & operator>>(std::ifstream &f, complexe &c) {
    f.read((char *) &c, sizeof(complexe));
    return f;
}*/

/*
 * Rôle : surchargé l'operateur << en écriture au format texte
*/
std::ostream & operator<<(std::ostream& f, const complexe &c) {
    return f << c.toString();
}

/*
 * Rôle : surchargé l'operateur >> en lecture au format texte
*/
std::istream & operator>>(std::istream& f, complexe &c) {
    c.lireComplexe(f);
    return f;
}