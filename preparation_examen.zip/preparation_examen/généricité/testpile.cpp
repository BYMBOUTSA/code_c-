#include <iostream>
#include <cstdlib>
#include "rectangle.hpp"
#include "pileChainee.hpp"
#include "pileVecteur.hpp"


int main () {

    rectangle r1(2.3, 1);
    rectangle r2(12.1, 0.43);

    pileChainee<std::string> t;
    t.empiler("charges");

    pileVecteur<int> pi;
    pileVecteur<std::string> ps;
    pileVecteur<rectangle> pr;

    pi.empiler(2);
    pi.empiler(4);
    ps.empiler("bienvenue");
    ps.empiler("world");
    pr.empiler(r1);
    pr.empiler(r2);

    std::cout << "--- état des piles ---" << std::endl;
    std::cout << pi.estVide() << std::endl;
    std::cout << ps.estVide() << std::endl;
    std::cout << pr.estVide() << std::endl;

    std::cout << "--- sommet des piles ---" << std::endl;
    std::cout << pi.sommet() << std::endl;
    std::cout << ps.sommet() << std::endl;
    std::cout << pr.sommet() << std::endl;

    std::cout << "--- affichage des piles sur la sortie standard ---" << std::endl;
    std::cout << pi << std::endl;
    std::cout << ps << std::endl;
    std::cout << pr << std::endl;

    pi.depiler();
    ps.depiler();
    pr.depiler();

    std::cout << "--- affichage des piles sur la sortie standard ---" << std::endl;
    std::cout << pi << std::endl;
    std::cout << ps << std::endl;
    std::cout << pr << std::endl;

    std::cout << "--- pile de piles d'entiers ---" << std::endl;
    pileVecteur<pileVecteur<int>> ppi;
    ppi.empiler(pi);
    std::cout << ppi << std::endl;
    std::cout << "--- pile de piles de chaînes de carctères ---" << std::endl;
    pileVecteur<pileVecteur<std::string>> pps;
    pps.empiler(ps);
    std::cout << pps << std::endl;
    std::cout << "--- pile de piles de rectangle ---" << std::endl;
    pileVecteur<pileVecteur<rectangle>> ppr;
    ppr.empiler(pr);
    std::cout << ppr << std::endl;

    std::cout << "--- pileChainee de pileVecteur de int ---" << std::endl;
    pileChainee<pileVecteur<int>> p;
    p.empiler(pi);
    std::cout << p << std::endl;
    std::cout << "--- pileVecteur de pileChainee de chaîne de caractères ---" << std::endl;
    pileVecteur<pileChainee<std::string>> s;
    s.empiler(t);
    std::cout << s << std::endl;

    return EXIT_SUCCESS;
}