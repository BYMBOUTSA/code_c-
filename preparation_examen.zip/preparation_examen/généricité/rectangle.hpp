#pragma once
#include <iostream>


class rectangle {
    private:
        double largeur;
        double longueur;
    public:
        rectangle(const double l = 0.0, const double L = 0.0) : largeur(l), longueur(L) {}
        ~rectangle() {
            std::cout << "Destruction du rectangle" << std::endl;
        }
        double getLargeur() const;
        void setLargeur(const double l);
        double getLongueur() const;
        void setLongueur(const double L);
        double surface() const;
        bool operator<(const rectangle &c) const;
        std::string toString() const;
        friend std::ostream & operator<<(std::ostream & f, const rectangle &r);
};