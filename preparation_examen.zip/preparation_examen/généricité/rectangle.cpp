#include <iostream>
#include "rectangle.hpp"

/*
 * Rôle : renvoie la largeur du rectangle courant
*/
double rectangle::getLargeur() const {
    return this->largeur;
}

/*
 * Rôle : modifier la largeur du rectangle courant 
*/
void rectangle::setLargeur(const double l) {
    this->largeur = l;
}

/*
 * Rôle : renvoie  la longueur du rectangle courant
*/
double rectangle::getLongueur() const {
    return this->longueur;
}

/*
 * Rôle : modifier la largeur du rectangle courant 
*/
void rectangle::setLongueur(const double L) {
    this->longueur = L;
}

/*
 * Rôle : renvoie la surface du rectangle courant
*/
double rectangle::surface() const {
    return (this->largeur * this->longueur);
}

/*
 * Rôle : surchargé l'opérateur < 
*/
bool rectangle::operator<(const rectangle &c) const {
    return (this->surface() < c.surface());
}

/*
 * Rôle : renvoie la représentation du rectangle courant en string 
*/
std::string rectangle::toString() const {
    return "(" + std::to_string(this->largeur) + ", " + std::to_string(this->longueur) + ")";
}

/*
 * Rôle : surchargé l'opérateur << sur ostream 
*/
std::ostream & operator<<(std::ostream &f, const rectangle &r) {
    return f << r.toString();
}