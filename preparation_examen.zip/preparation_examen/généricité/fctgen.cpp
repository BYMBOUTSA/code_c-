#include <iostream>
#include <cstdlib>
#include "rectangle.hpp"


//template <typename T>

/*const T & minimum(const T & x, const T & y) {
    return x < y ? x : y;
}*/

// modification de la fonction minimum en utilisant auto
const auto minimum(const auto &x, const auto &y) {
    return x < y ? x : y;
}


/*int main () {

    int a, b;
    std::cout << "entrée un entier a : ";
    std::cin >> a;
    std::cout << "entrée un entier b : ";
    std::cin >> b;

    double c, d;
    std::cout << "entrée un réel c : ";
    std::cin >> c;
    std::cout << "entrée un réel d : ";
    std::cin >> d;

    std::string s1, s2;
    std::cout << "entrée une chaîne s1 : ";
    std::cin >> s1;
    std::cout << "entrée une chaîne s2 : ";
    std::cin >> s2;

    std::cout << "Le minimum de deux entiers est : " << minimum(a, b) << std::endl;
    std::cout << "Le minimum de deux réels est : " << minimum(c, d) << std::endl;
    std::cout << "Le minimum de deux chaînes de caractères est : " << minimum(s1, s2) << std::endl;

    // affichage du minimum d'un entier et d'un réel
    //std::cout << minimum(a, c) << std::endl; // error no matching function, on a un problème car on utilise
    // une fonction avec deux types différents 

    // résolution du problème le type T au moment de l'appel de la fonction
    std::cout << minimum<double>(5.7, 13) << std::endl;
    std::cout << minimum<int>(5.7, 13) << std::endl;


    rectangle r1 = rectangle (2.3, 1);
    rectangle r2 = rectangle (12.1, 0.43);

    std::cout << "--- objet de type rectangle ---" << std::endl;
    std::cout << minimum(r1, r2) << std::endl; // ne fonctionne pas car on ne peut pas écrire le minimum d'un objet 
    // de type rectangle sur la sortie standard, il faut au préalable faire la surcharge de l'opérateur <<
    // après avoir fait la surcharge de l'opérateur < on a toujours le même problème, car il nous faut toujours faire la surcharge
    // de l'opérateur << pour écrire le minimum des deux rectangles sur la sortie standard

    // en utilisant auto dans la fonction minimum on a toujours le bon fonctionnement
    // car auto a bien pris le bon type chaque fois comme il se doit.

    return EXIT_SUCCESS;
}*/