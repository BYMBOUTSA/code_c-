#include <iostream>
#include "cercle.hpp"


/*
 * Rôle: renvoie le rayon de l'objet courant
*/
/*double cercle::getRayon() const {
    return ellipse::getPrayon();
}*/

/*
 * Rôle : modifie le rayon de l'objet courant 
*/
/*void cercle::setRayon(const double r) {
    ellipse::setPrayon(r);
    ellipse::setGrayon(r);
}*/

/*
 * Rôle : renvoie la chaîne "un cercle"
*/
/*std::string cercle::quiSuisJe() const {
    return "un cercle";
}*/

/*
 * Rôle : renvoie la représentation de l'objet courant en std::string 
*/
/*std::string cercle::toString() const {
    return "cercle(" + std::to_string(this->getRayon()) + ")";
}*/

/*
 * Rôle : surchargé l'opérateur << sur ostream 
*/
/*std::ostream & operator<<(std::ostream &f, const cercle &c) {
    return f << c.toString();
}*/