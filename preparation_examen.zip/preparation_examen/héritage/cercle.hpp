#pragma once
#include <iostream>
#include <cassert>
#include "ellipse.hpp"


class cercle : public ellipse {
    public:
        cercle(const double r = 0.0) : ellipse(r, r) {}
        // conversion de l'ellipse en cercle
        cercle(const ellipse &e) : ellipse(e.getPrayon(), e.getGrayon()) {
            assert(e.getPrayon() == e.getGrayon());
        }
        ~cercle() {
            std::cout << "Destruction du cercle" << std::endl;
        }

        //double getRayon() const;
        //void setRayon(const double r);

        // on retire les méthodes getPrayon(), getGrayon(), setPrayon() et setGrayon()
        double getPrayon() const = delete;
        double getGrayon() const = delete;
        void setPrayon(const double pr) = delete;
        void setGrayon(const double gr) = delete;

        //std::string quiSuisJe() const;
        //std::string toString() const;
        //friend std::ostream & operator<<(std::ostream &f, const cercle &c);


        /*
        * Rôle: renvoie le rayon de l'objet courant
        */
        double getRayon() const {
            return ellipse::getPrayon();
        }

        /*
        * Rôle : modifie le rayon de l'objet courant 
        */
        void setRayon(const double r) {
            ellipse::setPrayon(r);
            ellipse::setGrayon(r);
        }

        /*
        * Rôle : renvoie la chaîne "un cercle"
        */
        std::string quiSuisJe() const override {
            return "un cercle";
        }

        /*
        * Rôle : renvoie la représentation de l'objet courant en std::string 
        */
        std::string toString() const override {
            return "cercle(" + std::to_string(this->getRayon()) + ")";
        }

        /*
        * Rôle : surchargé l'opérateur << sur ostream 
        */
        friend std::ostream & operator<<(std::ostream &f, const cercle &c) {
            return f << c.toString();
        }

};