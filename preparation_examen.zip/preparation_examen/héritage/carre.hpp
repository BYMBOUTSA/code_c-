#pragma once
#include <iostream>
#include <cassert>
#include "rectangle.hpp"


class carre : public rectangle {
    private:
        double cote;
    public:
        carre(const double c = 0.0) : rectangle(c, c) {}
        // conversion du rectangle en carré
        carre(const rectangle &r) : rectangle(r.getLargeur(), r.getLongueur()) {
            assert(r.getLargeur() == r.getLongueur());
        }
        ~carre() {
            std::cout << "Destruction du carré" << std::endl;
        }
        double getCote() const;
        void setCote(const double c);
        /*double perimetre() const;
        double surface() const;*/
        // rédéfinition de la méthode toString() et la surcharge de l'opérateur << 
        std::string toString() const override;
        friend std::ostream & operator<<(std::ostream &f, const carre &c);

        // annulation des méthodes getLargeur(), getLongueur(), setLargeur(), setLongueur()
        double getLargeur() const = delete;
        double getLongueur() const = delete;
        void setLargeur() = delete;
        void setLongueur() = delete;

        std::string quiSuisJe() const override;
};