#pragma once
#include <iostream>
#include <cassert>
#include "figure.hpp"


class ellipse : public figure {
    protected:
        double prayon;
        double grayon;
    public:
        ellipse(const double pr = 0.0, const double gr = 0.0) : prayon(pr), grayon(gr) {
            assert(pr >= 0 && gr >= 0);
        }
        ~ellipse() {
            std::cout << "Destruction de l'ellipse" << std::endl;
        }
        double getPrayon() const;
        void setPrayon(const double pr);
        double getGrayon() const;
        void setGrayon(const double gr);
        double perimetre() const override;
        double surface() const override;
        std::string quiSuisJe() const override;
        std::string toString() const override;
        friend std::ostream & operator<<(std::ostream &f, const ellipse &e);

};