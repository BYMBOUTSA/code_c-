#include <iostream>
#include <cstdlib>
#include <vector>
#include "rectangle.hpp"
#include "carre.hpp"
#include "ellipse.hpp"
#include "cercle.cpp"
#include "figure.hpp"


void afficher(const figure * f) {
    std::cout << "Je suis " << f->quiSuisJe() << std::endl;
}


int main () {

    std::cout << "--- objet de type rectangle ---" << std::endl;
    rectangle r1 (2.6, 4.42), r2;

    std::cout << r1.perimetre() << std::endl;
    r1.setLargeur (3.9);

    std::cout << "--- objet de type carre ---" << std::endl;
    carre c1(3.8), c2;
    std::cout << c1.perimetre() << std::endl;
    //c2.setCote(2.9);
    // application de la méthode setLongueur() sur l'objet de type carre
    //c2.setLongueur(2.9);
    //std::cout << c2.getLongueur() << std::endl; // oui, il est possible d'appliquer setLongueur() à un objet de type carre
    // oui c'est normal, mais ce n'est pas correct car ça va amener, un carré qui à deux cotés différents pendant que ce n'est pas possible
    // pour éviter cela il faut annuler, l'utilisation des propriétés getLongueur(), getLargeur(), setLongueur() et setLargeur() dans l'objet de type carre

    // teste de la méthode quiSuisJe()
    std::cout << "--- quiSuisJe ---" << std::endl;
    std::cout << r1.quiSuisJe() << std::endl;
    std::cout << c1.quiSuisJe() << std::endl;
    // qu'on a la même chaîne pour les deux objets r1 et c1
    // après avoir défini la méthode quiSuisJe() dans l'objet de type carre, on a bien la chaîne correcte

    // Déclaration d'une variable f de type figure
    /*figure f;
    std::cout << f.quiSuisJe() << std::endl;*/

    // polymorphisme
    std::cout << "--- polymorphisme ---" << std::endl;
    rectangle r3 = carre(8);
    //rectangle r4 = cercle(8); // il y a une erreur, car le cercle n'est pas un rectangle particulier
    // pour que sa marche il faut faire une conversion implicite

    // remplacement de la déclaration de la variable r4 par
    //carre r4 = rectangle (2, 8); // c'est fonctionnel à cause de la conversion qui s'effectue dans ce constructeur carre(const rectangle &r)
    // car ce constructeur nous permet de faire la conversion du rectangle en carré

    // remplacement de la déclaration de la variable r4 par
    carre r4 = r3; // il y a une erreur si nous ne faisons pas la conversion car r3 est un rectangle et r4 est un carré, et comme un carré n'est pas un rectangle particulier nous avons une erreur 
    // par défaut qui est retiré juste quand on fait la conversion de r3 en carré

    // liaison dynamique
    std::cout << "--- liaison dynamique ---" << std::endl;
    rectangle * r = new carre(8);
    afficher(r);
    ellipse * c = new cercle(8);
    afficher(c);
    // le résultat obtenu n'est pas satisfaisant, en toute logique on devait avoir "je suis carré" et "je suis un cercle" car c'est bien ces figure qui ont été alloués

    // déclaration une variable vf de type vecteur de figure *
    // ajouter dans ce vecteur plusieurs rectangles, carrés, ellipses et cercles
    std::vector<figure *> vf = {new rectangle(1.5, 1.3), new carre(1.6), new ellipse(3, 2.6), new cercle(2)};

    // avec l'énoncé foreach parcourons le vecteur pour afficher la nature des figures sur la sortie standard ainsi que les surfaces
    for (figure * f : vf) {
        afficher(f);
        std::cout << "de surface = " << f->surface() << std::endl;
    }
    // le problème qu'on a est qu'on a pas la méthode surface() dans l'objet de type figure 

    return EXIT_SUCCESS;
}