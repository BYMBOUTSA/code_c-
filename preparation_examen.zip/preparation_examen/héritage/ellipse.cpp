#include <iostream>
#include <cmath>
#include "ellipse.hpp"
#include "figure.hpp"

/*
 * Rôle : renvoie le petit rayon de l'objet courant 
*/
double ellipse::getPrayon() const {
    return this->prayon;
}

/*
 * Rôle : modifier le petit rayon de l'objet courant 
*/
void ellipse::setPrayon(const double pr) {
    this->prayon = pr;
}

/*
 * Rôle : renvoie le grand rayon de l'objet courant 
*/
double ellipse::getGrayon() const {
    return this->grayon;
}

/*
 * Rôle : modifier le grand rayon de l'objet courant 
*/
void ellipse::setGrayon(const double gr) {
    this->grayon = gr;
}

/*
 * Rôle : renvoie le perimètre de l'objet courant 
*/
double ellipse::perimetre() const {
    return M_PI * sqrt(2 * (this->prayon * this->prayon + this->grayon * this->grayon));
}

/*
 * Rôle : renvoie la surface de l'objet courant 
*/
double ellipse::surface() const {
    return M_PI * (this->prayon * this->grayon);
}

/*
 * Rôle : renvoie la chaîne de caractère "une ellipse" 
*/
std::string ellipse::quiSuisJe() const {
    return "une ellipse";
}

/*
 * Rôle : renvoie la représentation de l'objet courant en std::string 
*/
std::string ellipse::toString() const  {
    return "ellipse(" + std::to_string(this->prayon) + ", " + std::to_string(this->grayon) + ")";
}

/*
 * Rôle : surchargé l'opérateur << sur ostream 
*/
std::ostream & operator<<(std::ostream &f, const ellipse &e) {
    return f << e.toString();
}