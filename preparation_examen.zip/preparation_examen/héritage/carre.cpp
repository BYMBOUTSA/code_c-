#include <iostream>
#include "carre.hpp"


/*
 * Rôle : renvoie le coté de l'objet courant 
*/
double carre::getCote() const {
    return rectangle::getLargeur();
}

/*
 * Rôle : modifier le coté de l'objet courant 
*/
void carre::setCote(const double c) {
    rectangle::setLargeur(c);
    rectangle::setLongueur(c);
}

/*
 * Rôle : renvoie le perimètre de l'objet courant
*/
/*double carre::perimetre() const {
    return (this->cote * 4);
}*/

/*
 * Rôle : renvoie la surface de l'objet courant
*/
/*double carre::surface() const {
    return (this->cote * this->cote);
}*/

/*
 * Rôle : renvoie le représentation de l'objet courant en std::string 
*/
std::string carre::toString() const {
    return "carre(" + std::to_string(this->cote) + ")";
}

/*
 * Rôle : surchargé de l'opérateur << sur ostream 
*/
std::ostream & operator<<(std::ostream &f, const carre &c) {
    return f << c.toString();
}

/*
 * Rôle : renvoie la chaîne de caractère "un carré" 
*/
std::string carre::quiSuisJe() const {
    return "un carré";
}