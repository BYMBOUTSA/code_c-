#include <iostream>
#include "rectangle.hpp"
#include "figure.hpp"

/*
 * Rôle : renvoie la largeur de l'objet courant 
*/
double rectangle::getLargeur() const {
    return this->largeur;
}

/*
 * Rôle : modifier la largeur de l'objet courant
*/
void rectangle::setLargeur(const double l) {
    this->largeur = l;
}

/*
 * Rôle : renvoie la longueur de l'objet courant 
*/
double rectangle::getLongueur() const {
    return this->longueur;
}

/*
 * Rôle : modifier la longueur de l'objet courant
*/
void rectangle::setLongueur(const double L) {
    this->longueur = L;
}

/*
 * Rôle : renvoie le perimètre de l'objet courant
*/
double rectangle::perimetre() const {
    return (this->largeur + this->longueur) * 2;
}

/*
 * Rôle : renvoie la surface de l'objet courant
*/
double rectangle::surface() const {
    return (this->largeur * this->longueur);
}

/*
 * Rôle : surchargé l'opérateur <
*/
bool rectangle::operator<(const rectangle &c) const {
    return (this->surface() < c.surface());
}

/*
 * Rôle : renvoie une représentation en std::string de l'objet courant
*/
std::string rectangle::toString() const {
    return "rectangle(" + std::to_string(this->largeur) + ", " + std::to_string(this->largeur) + ")";
}

/*
 * Rôle : surchargé l'opérateur << sur ostream 
*/
std::ostream & operator<<(std::ostream &f, const rectangle &r) {
    return f << r.toString();
}

/*
 * Rôle : renvoie la chaîne de carcatère "un rectangle" 
*/
std::string rectangle::quiSuisJe() const {
    return "un rectangle";
}
