#include <iostream>
#include <cstdlib>
#include "pileChainee.hpp"
#include "pileVecteur.hpp"
#include "rectangle.hpp"
#include "carre.hpp"
#include "pile.hpp"

void afficher(const pile<int> * p) {
    std::cout << "Je suis " << p->quiSuisJe() << std::endl;
}

int main () {

    rectangle r1 = carre(8);
    rectangle r2 (2.6, 4.42);

    pileChainee<std::string> t;
    t.empiler("charges");

    pileChainee<int> p;
    std::cout << p.estVide() << std::endl;
    p.empiler(6);
    p.empiler(15);
    std::cout << p.sommet() << std::endl;
    std::cout << p.estVide() << std::endl;
    std::cout << p.sommet() << std::endl;
    p.depiler();
    std::cout << p.sommet() << std::endl;
    std::cout << p << std::endl;

    pileVecteur<int> pi;
    pileVecteur<std::string> ps;
    pileVecteur<rectangle> pr;

    pi.empiler(2);
    pi.empiler(4);
    ps.empiler("Bonjour");
    ps.empiler("world");
    pr.empiler(r1);
    pr.empiler(r2);

    std::cout << "--- états des piles ---" << std::endl;
    std::cout << pi.estVide() << std::endl;
    std::cout << ps.estVide() << std::endl;
    std::cout << pr.estVide() << std::endl;

    std::cout << "--- sommets des piles ---" << std::endl;
    std::cout << pi.sommet() << std::endl;
    std::cout << ps.sommet() << std::endl;
    std::cout << pr.sommet() << std::endl;

    std::cout << "--- affichage des piles sur std::cout ---" << std::endl;
    std::cout << pi << std::endl;
    std::cout << ps << std::endl;
    std::cout << pr << std::endl;

    // on dépile les sommet de chaque piles
    pi.depiler();
    ps.depiler();
    pr.depiler();

    std::cout << "--- affichage des piles sur std::cout ---" << std::endl;
    std::cout << pi << std::endl;
    std::cout << ps << std::endl;
    std::cout << pr << std::endl;

    // Ajout de la déclaration d'une variable ppi qui est une pile d'entier
    pileVecteur<pileVecteur<int>> ppi;
    ppi.empiler(pi);
    std::cout << ppi << std::endl;

    // Construction et affichage d'une pileChainee de pileVecteur de int
    pileChainee<pileVecteur<int>> ppr;
    ppr.empiler(pi);
    std::cout << ppr << std::endl;

    // Construction et affichage d'une pileVecteur de pileChainee de std::string
    std::cout << "--- pileVecteur de pileChainee de chaîne de caractères ---" << std::endl;
    pileVecteur<pileChainee<std::string>> s;
    s.empiler(t);
    std::cout << s << std::endl;

    std::cout << "--- nature de la pile ---" << std::endl;
    pileChainee<int> * pt = new pileChainee<int>;
    afficher(pt);
    pileVecteur<int> * pe = new pileVecteur<int>;
    afficher(pe);
    pile<int> * dc = new pileChainee<int>;
    afficher(dc);
    pile<int> * dv = new pileVecteur<int>;
    afficher(dv);
    
    std::cout << "--- affichage de la pile ---" << std::endl;
    pile<pileVecteur<rectangle>> * pd = new pileChainee<pileVecteur<rectangle>> ();
    pd->empiler(pr);
    pr.empiler(rectangle(7, 3.5));
    pd->empiler(pr);
    std::cout << *pd << std::endl;
    


    return EXIT_SUCCESS;
}