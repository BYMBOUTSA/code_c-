#pragma once
#include <iostream>
#include <cassert>
#include <sstream>
#include <vector>
#include <initializer_list>
#include "pile.hpp"

template <typename T>

class pileVecteur : public pile<T> {
    private:
       std::vector<T> lesElements; // tableau générique d'éléments de type T 
    public:
        // comme on utilise une classe du langage on n'a pas besoin de constructeur, car il est déjà fournis
        // s'il fallait le faire, il doit être défini comme ci-dessous
        pileVecteur(const std::initializer_list<T> &init) {
            for (T x : init)
                this->empiler(x);
        }

        pileVecteur() {}

        /*
         * Rôle : renvoie true si le tableau courant est vide sinon false
        */
        bool estVide() const override {
            // teste de l'état de la pile
            return (this->lesElements.empty());
        }

        /*
         * Rôle : ajouter l'élément x en sommet de la pile courante
        */
        void empiler(const T &x) override {
            // ajout de l'élément x en sommet de la pile
            this->lesElements.push_back(x);
        }

        /*
         * Rôle : retirer l'élément en sommet de la pile courante
        */
        void depiler() override {
            // on vérifie l'état de la pile
            assert(!this->estVide());
            // on retire l'élément qui se trouve en sommet de la pile
            this->lesElements.pop_back();
        }

        /*
         * Rôle : renvoie la valeur du sommet de la pile courante
        */
        T sommet() const override {
            // on vérifie l'état de la pile
            assert(!this->estVide());
            // on retourne le dernier éléments de la pile
            return this->lesElements.back();
        }

        /*
         * Rôle : renvoie une représentation en std::string de la pile courante
        */
        std::string toString() const override {
            // on  initialise la chaîne s
            std::ostringstream s;
            s << "[";
            // on parcours tous les éléments de la pile
            for (unsigned int i = 0; i < this->lesElements.size(); i++)
                // on écrit chacun des éléments du tableau suivi d'un espace
                s << this->lesElements[i] << " ";
            // après avoir mis tous les éléments du tableau on ajoute le crochet fermant    
            s << "]";
            // on retourne la chaîne de caractère crée
            return s.str(); 
        }

        friend std::ostream & operator<<(std::ostream &f, const pileVecteur &p) {
            return f << p.toString();
        }

        std::string quiSuisJe() const override {
            return "une pile de Vecteur";
        }

};