#pragma once
#include <iostream>
#include <sstream>
#include <cassert>
#include "pile.hpp"


template <typename T>

class noeud {
    private:
        T elt;
        noeud<T> * suivant;
    public:
        noeud(const T e, noeud<T> * s = nullptr) : elt(e), suivant(s) {}
        ~noeud() {
            std::cout << "Destruction du noeud" << std::endl;
        }
        /*
        * Rôle : renvoie la valeur de l'élément 
        */
        T getElement() const {
            return this->elt;
        }

        /*
        * Rôle : modifier la valeur de l'élément 
        */
        void setElement(const T e) {
            this->elt = e;
        }

        /*
        * Rôle : renvoie la valeur de l'élément suivant
        */
        noeud<T> * getSuivant() const {
            return this->suivant;
        }

        /*
        * Rôle : modifier la valeur de l'élément suivant
        */
        void setSuivant(noeud<T> * s) {
            this->suivant = s;
        }

        /*
        * Rôle : renvoie la représentation sous forme de std::string de l'objet courant 
        */
        // avec l'utilisation du flux (ogstringstream)
        std::string toString() const {
            std::ostringstream s;
            s << this->elt;
            return s.str();
        }

        // sans l'utilisation du flux 
        /*std::string toString() const {
            std::string s;
            s = std::to_string(this->elt); // écriture de l'élément dans le flux s
            return s; // retourne la conversion de l'ostringstream en chaîne de carctère
        }*/

        // sans l'utilisation du flux avec l'ajout des crochets dans l'affichage
        /*std::string toString() const {
            std::string s = "[";
            s += std::to_string(this->elt); // écriture de l'élément dans le flux s
            return s + "]"; // retourne la conversion de l'ostringstream en chaîne de carctère
        }*/

        /*
        * Rôle : surchargé l'opérateur << sur ostream
        */
        friend std::ostream & operator<<(std::ostream &f, const noeud<T> &n) {
            return f << n.toString();
        }
};


template <typename T>

class pileChainee : public pile<T> {
    private:
        noeud<T> *sp; // le sommet de la pile
        // Méthodes privées

        /*
        * Rôle : supprimer le noeud n et les suivants
        */
       // méthode pour supprimer tous les éléments de liste de noeuds n
        // 1ère version : récursive
        void detruire(noeud<T> *n) {
            // s'il y a encore des noeuds
            if (n != nullptr) {
                detruire(n->getSuivant());
                delete n;
            }
        }

        // 2ème méthode : itérative
        /*void detruire(noeud<T> * n) {
            // tant que la pile n'est pas vide
            while (n != nullptr) {
                // on crée un noeud qui va pointer sur le noeud suivant
                noeud<T> *p = n->getSuivant();
                // on retire le noeud précédent
                delete n;
                // on positionne les pointeurs sur le même noeud
                n = p;
            }
        }*/

        /*
        * Rôle : duplique le noeud n et les suivants
        */
        // méthode pour dupliquer tous les éléments de liste de noeuds n
        // 1ère méthode : récursive
        noeud<T> * dupliquer(noeud<T> * n) {
            // si la pile est vide
            if (n == nullptr) return nullptr;
            // sinon on copie le noeud suivant
            noeud<T> * p = dupliquer(n->getSuivant());
            // on retourne le nouveau noeud<T> avec sa valeur et son pointeur 
            return new noeud<T>(n->getElement(), p);
        }

        // 2ème méthode : itérative
        /*noeud<T> * dupliquer(noeud<T> * n) {
            if (n == nullptr) return nullptr;
            // création du premier noeud
            noeud<T> * p = new noeud<T>(n->getElement());
            // on positionne les pointeur au même endroit
            noeud<T> * q = p;
            // tant que le noeud suivant ne pointe pas sur nullptr
            while ((n = n->getSuivant()) != nullptr) {
                // on crée un nouveau noeud
                noeud<T> *t = new noeud<T>(n->getElement());
                // on modifie le pointeur suivant
                q->setSuivant(t);
                // on positionne les pointeurs sur le même noeud
                q = t;
            }
            return p;
        }*/

    
    public:
        pileChainee(noeud<T> *s = nullptr) : sp(s) {}
        // constructeur de copie
        pileChainee(const pileChainee &p) {
            this->sp = this->dupliquer(p.sp);
        }
        ~pileChainee() {
            std::cout << "Destruction de la pile" << std::endl;
            this->detruire(this->sp);
        }
        
        // Méthodes publiques

        /*
        * Rôle : renvoie true si la pile courante est vide sinon false
        */
        bool estVide() const override {
            // on teste si le pointeur de sommet pointe sur nullptr
            // si c'est le cas c'est que la pile est vide sinon il y a des éléments
            return (this->sp == nullptr);
        }

        /*
        * Rôle : ajouter l'élément x en sommet de la pile courante
        */
        void empiler(const T & x) override {
            // création du noeud
            noeud<T> * p = new noeud<T>(x, this->sp);
            // on place le noeud crée en sommet de la pile courante
            this->sp = p;
        }

        /*
        * Rôle : retirer l'élement en sommet de la pile courante
        */
        void depiler() override {
            // on vérifie que la pile ne soit pas vide
            assert(!this->estVide());
            // on positionne le pointeur p en sommet de la pile
            noeud<T> * p = this->sp;
            // on déplace le pointeur courant sur l'élément suivant
            this->sp = this->sp->getSuivant();
            // on retire le sommet de la pile (destruction du noeud)
            delete p;
        }

        /*
        * Rôle : renvoie l'entier en sommet de la pile
        */
        T sommet() const override {
            // on vérifie que la pile ne soit pas vide
            assert(!this->estVide());
            // on renvoie la valeur du sommet de la pile
            return this->sp->getElement();
        }

        /*
        * Rôle : renvoie la représentation de l'objet courant sous forme d'une string
        */
        // en passant par le flux (ostringstream)
        std::string toString() const override {
            // initialisation de s
            std::ostringstream s;
            s << "[";
            // on crée un pointeur sur le sommet de la pile
            noeud<T> * n = this->sp;
            // tant que la pile n'est pas vide
            while (n != nullptr) {
                // on met chacun des éléments pointés dans le flux
                s << *n << " ";
                n = n->getSuivant(); // on se positionne sur le noeud suivant 
            }
            // on met le crocher fermant dans le flux
            s << "]";
            // on retourne la chaiîne de caractère représenté par le flux 
            return s.str();
        }

        // en passant par une string
        /*std::string toString() const {
            std::string s = "[";
            noeud<T> * n = this->sp;
            while(n != nullptr) {
                s += std::to_string(n->getElement()) + " ";
                n = n->getSuivant();
            }
            return s + "]";
        }*/

        /*
        * Rôle : surchargé l'opérateur << sur ostream
        */
        friend std::ostream & operator<<(std::ostream &f, const pileChainee &p) {
            return f << p.toString();
        }

        /*
        * Rôle :  surchargé l'opérateur d'affectation  
        */
        pileChainee & operator=(const pileChainee &p) {
            std::cout << "affectation copie de la pile" << std::endl;
            this->sp = dupliquer(p.sp); // on fait la copie de p dans sp
            return *this; // renvoie le pointeur sur le noeud courant
        }

        std::string quiSuisJe() const override{
            return "une pile Chainée";
        }
};