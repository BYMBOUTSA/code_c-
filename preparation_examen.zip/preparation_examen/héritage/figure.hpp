#pragma once
#include <iostream>

// classe abstraite car elle possède au moins une méthode virtuelle pure
class figure {
    public:
        virtual ~figure() {
            std::cout << "Destruction de la figure" << std::endl;
        }
        virtual std::string quiSuisJe() const {
            return "une figure";
        }
        // comme on ne peut pas déterminer ni la surface, ni le perimètre d'une figure quelconque
        // alors on les définis de façon virtuelle pures en ajoutant à la fin des prototypes = 0
        virtual double surface() const = 0; // méthode virtuelle pure à cause du = 0 à la fin de la méthode
        virtual double perimetre() const = 0; 
        virtual std::string toString() const = 0;

        // utilisation de la liaison dynamique pour pouvoir écrire la bonne figure sur la console
        friend std::ostream & operator<<(std::ostream &f, const figure &fig) {
            return f << fig.toString();
        }
};